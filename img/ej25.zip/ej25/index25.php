<!DOCTYPE html>
<html lang="es">

	<head>
		<title>JuegosGuapos</title>
		
		<meta charset="utf-8">
		
		<!-- Añadimos un meta para la correcta visualización en dispositivos smartphone -->
		<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1">
		<script
			src="https://code.jquery.com/jquery-3.6.0.js"
			integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
			crossorigin="anonymous">
		</script>
		<link rel="stylesheet" type="text/css" href="css/estilos.css">

		<?php
		$arrayJuegos = [];
		define("NORMAL", 1);
		define("OFERTA", 2);
		function completarArray(&$arrayJuegos){
			$juego = fopen("games.txt", "r");
			while (!feof($juego)) {
				// Leemos los juegos linea a linea
				$linea = utf8_encode( fgets( $juego ) );
				// Guardamos en variables el codigo y el nombre del juego.
				$gameCode = substr($linea, 0, 4);
				$gameName = substr($linea, 5);
				// Vamos añadiendo los juegos en el array utilizando un intermediario y la funcion 'array_merge'
				$intermediario = array( "$gameCode" => "$gameName" );
				$arrayJuegos = array_merge($arrayJuegos, $intermediario);
			}
			fclose($juego);
		}
		function imprimirInfo($code){
			$info = fopen('info.txt', "r");
			// Imprimir la informacion de cada juego codigo por codigo.
			while(!feof($info)){
				$codigo = fgets($info);
				if(substr($codigo,0,4) == $code){
					echo substr($codigo,5);
				}
			}
			fclose($info);
		}
		function imprimirMarco($code,$name,$tipo){
			// imprimimos la imagen en funcion del juego que sea.
			$imagen = "<img src='images/$code.jpg' alt='$name'>";
			?>
			<div class="imagen" ><?php echo $imagen; ?></div>
			<h2><?php echo $name; ?></h2>
			<div class="info" >
			<?php imprimirInfo( $code ); ?>	
			</div>
			<?php
			// Generamos un precio aleatorio
			$precio = rand(50,80);
			// Mostramos el precio en funcion de si la funcion ha sido llamada desde el mosaico(1) o desde la oferta(2).
			if($tipo == 1){
				$precioIVA = $precio + ($precio*0.21);
				?>
				<p><?php echo $precioIVA . "€"; ?></p>
				<?php
			}else if($tipo == 2){
				$descuento = 10;
				$precioDescuento = $precio + ($precio*0.21) - ($precio*($descuento/100));
				?>
				<p><?php echo $precioDescuento . "€"; ?></p>
				<?php
			}
		}

		function imprimirMosaico(&$arrayJuegos){
			// Recorremos el array de juegos y vamos imprimiendo cada marco juego por juego
			foreach ($arrayJuegos as $code => $name) {
				?><div class="juego" id="<?php echo $code; ?>">
					<?php imprimirMarco($code,$name,NORMAL); ?>	
				</div>
				<?php
			}
		}
		// Funcion que elegira dos juegos aleatorios para hacer una promocion de ellos
		function juegoRand(&$arrayJuegos){
			$numJuegos = count($arrayJuegos) - 1;
			// Esta forma de elegir los juegos se podria hacer con array_rand(), pero lo hice antes de darlo
			$oferta1 = rand(0,$numJuegos);
			do{
				$oferta2 = rand(0,$numJuegos);
			}while($oferta1 == $oferta2);
			// Creamos un array con todas las claves
			$claves = array_keys($arrayJuegos);
			$clave1 = $claves[$oferta1];
			$clave2 = $claves[$oferta2];
			?>
			<div class="juego"><?php imprimirMarco($clave1, $arrayJuegos[$clave1],OFERTA); ?></div>
			<div class="juego"><?php imprimirMarco($clave2, $arrayJuegos[$clave2],OFERTA); ?></div>
			<?php
 		}
 		?>
 		<script type="text/javascript">
 			// JQuery que muestra y oculta la info de los juegos segun clickes en ellos
 			$( document ).ready(function(){
 				$("div.juego").click(function(){
 					idJuego = this.id;
 					selector="#"+idJuego+" div.info";
 					$(selector).toggle();
 				});
 			});
 			// Funciones que muestran y ocultan la promocion cada x tiempo
 			function banerPromocion(){
				document.getElementById('promocion').style.display='flex';
				setTimeout("iniciarPromocion()",5000);
 			}

 			function iniciarPromocion(){
 				document.getElementById('promocion').style.display='none';
 				setTimeout("banerPromocion()",10000);

 			}
 		</script>
 		<?php 
 		// Llamamos a la funcion para inicializar el array de Juegos para empezar a imprimir la web
 		completarArray($arrayJuegos); 
 		?>
	</head>
	
	<body>
		<div id="header">
			<h1>JuegosGuapos.com</h1>
		</div>
		<div id="promocion">
			<?php juegoRand($arrayJuegos); ?>
			<script type="text/javascript"> iniciarPromocion(); </script>
		</div>
		<div id="mosaico">
			<?php imprimirMosaico($arrayJuegos); ?>
		</div>
	</body>
	
</html>